﻿using smartpharma.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace smartpharma.Models
{
    public class StockModel
    {
        Database1Entities db = new Database1Entities();

        public List<StockVM> GetStockList()
        {
            List<StockVM> lstStocks = new List<StockVM>();
            lstStocks = (from s in db.Stocks
                            select new StockVM()
                            {
                                
                                Item_Name = s.Item.Item_Name,
                                Current_Stock=s.Current_Stock,
                                Image_Path=s.Item.Item_Path
                               
                                
                            }).ToList();
            return lstStocks;


        }


    }
}