﻿using smartpharma.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace smartpharma.Models
{
    public class MfgModel
    {
        Database1Entities db = new Database1Entities();

        public List<MfgVM> GetMfgList()
        {
            List<MfgVM> lstMfgs = new List<MfgVM>();
            lstMfgs = (from m in db.Mfgs
                            select new MfgVM()
                            {
                                Mfg_Id = m.Mfg_Id,
                                Mfg_Name = m.Mfg_Name,
                                Mfg_Address = m.Mfg_Address,
                              
                                Mfg_Email = m.Mfg_Email,
                                Contact = m.Contact,
                                Gst_No=m.Gst_No,
                                Pan_No=m.Pan_No,

                            }).ToList();
            return lstMfgs;


        }

        public bool Create(MfgVM obj)
        {
            try
            {
                Mfg m = new Mfg();
                m.Mfg_Name = obj.Mfg_Name;
                m.Mfg_Address = obj.Mfg_Address;
                m.Gst_No = obj.Gst_No;
                m.Mfg_Email = obj.Mfg_Email;
                m.Contact = obj.Contact;
                m.Pan_No = obj.Pan_No;
                db.Mfgs.Add(m);
                db.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;

            }

        }

        public bool Delete(int id)
        {
            try
            {
                Mfg m;
                m = db.Mfgs.Where(a => a.Mfg_Id == id).FirstOrDefault();
                if (m != null)
                {
                    db.Mfgs.Remove(m);
                    db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                return false;
            }

        }

        public MfgVM GetMfgDetails(int id)
        {
            try
            {
                MfgVM mVM = new MfgVM();
                mVM = (from m in db.Mfgs.Where(m => m.Mfg_Id == id)
                       select new MfgVM()
                       {
                Mfg_Id = m.Mfg_Id,
                Mfg_Name = m.Mfg_Name,
                Mfg_Address = m.Mfg_Address,
                Mfg_Email = m.Mfg_Email,
                Contact = m.Contact,
                Gst_No = m.Gst_No,
                Pan_No = m.Pan_No           
            }).FirstOrDefault();
                return mVM;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                throw;
            }

        }

        public bool UpdateMfg(MfgVM obj)
        {
            try
            {
                Mfg m;
                m = db.Mfgs.Where(a => a.Mfg_Id == obj.Mfg_Id).FirstOrDefault();
                if (m != null)
                {

            m.Mfg_Name = obj.Mfg_Name;
            m.Mfg_Address = obj.Mfg_Address;
            m.Gst_No = obj.Gst_No;
            m.Mfg_Email = obj.Mfg_Email;
            m.Contact = obj.Contact;
            m.Pan_No = obj.Pan_No;
            db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }


            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                return false;
            }

        }
    }
}