﻿using System.Web.Mvc;
using smartpharma.Helper;
using smartpharma.ViewModel;
using System.Web.Security;
using System.Web.Routing;

namespace smartpharma.Controllers
{
    public class baseuserController : Controller
    {
        protected LoginVM uiDTO;

        public baseuserController()
        {
            this.uiDTO = AppHelper.GetUserInfoDTOFromSession();
        }

        protected override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (string.IsNullOrEmpty(this.uiDTO.Email_Id))
            {
                Response.Redirect("~/Admin/login", true);
            }
        }
    }
}