﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace smartpharma.ViewModel
{
    public class ItemImageVM
    {
        public int ItemImage_Id { get; set; }

        public int Item_Id { get; set; }

        public string Image_Path { get; set; }
    }
}