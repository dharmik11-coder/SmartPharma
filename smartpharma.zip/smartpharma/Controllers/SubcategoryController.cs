﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using smartpharma.Models;
using smartpharma.ViewModel;
using System.IO;

namespace smartpharma.Controllers
{
    public class SubcategoryController : Controller
    {
        // GET: Subcategory
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SubcategoryList()
        {
            SubcategoryModel model = new SubcategoryModel();
            List<SubcategoryVM> lstSubcategory = new List<SubcategoryVM>();
            lstSubcategory = model.GetSubcategoryList();
            return View(lstSubcategory);
        }


        [HttpGet]
        public ActionResult Edit(int id)
        {
            SubcategoryVM sVM = new SubcategoryVM();
            SubcategoryModel model = new SubcategoryModel();
            sVM = model.GetSubcategoryDetails(id);
            ViewBag.DDLCategory = model.DDLCategory();
            return View(sVM);
        }
        [HttpPost]
        public ActionResult Edit(SubcategoryVM obj)
        {
            
            SubcategoryModel model = new SubcategoryModel();
            if (ModelState.IsValid)
            {
              
                bool isUpdated = false;
                isUpdated = model.UpdateSubcategory(obj);
                if (isUpdated)
                {
                    return RedirectToAction("SubcategoryList");
                }
                else
                {
                    ViewBag.DDLCategory = model.DDLCategory();
                    return View();
                }

            }
            else
            {
                ViewBag.DDLCategory = model.DDLCategory();
                return View();
            }
        }


        [HttpGet]
        public ActionResult Delete(int id)
        {
            bool isDeleted = false;
            SubcategoryModel model = new SubcategoryModel();
            isDeleted = model.Delete(id);
            if (isDeleted)
            {
                return RedirectToAction("SubcategoryList");
            }
            else
            {
                ViewBag.ItemDeleteErrorMessage = "Subcategory can not delete";
                return RedirectToAction("SubcategoryList");

            }

        }
        [HttpGet]
        public ActionResult Create()
        {
            SubcategoryModel model = new SubcategoryModel();
            ViewBag.DDLCategory = model.DDLCategory();
            return View();
        }


        public ActionResult Create(SubcategoryVM obj)
        {
            bool isAdded = false;
            SubcategoryModel model = new SubcategoryModel();
            if (ModelState.IsValid)
            {               
               
                isAdded = model.Create(obj);
                if (isAdded)
                {
                    return RedirectToAction("SubcategoryList");
                }
                else
                {
                    ViewBag.DDLCategory = model.DDLCategory();
                    return View();
                }
            }
            else
            {
                ViewBag.DDLCategory = model.DDLCategory();
                return View();
            }

        }

    }
}