﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace smartpharma.ViewModel
{
    public class MfgVM
    {

        public int Mfg_Id { get; set; }

        [Display(Name = "Manufacture Name")]
        [Required]
        public string Mfg_Name { get; set; }

        [Required]
        public string Mfg_Address { get; set; }

        [Display(Name = "Email Id")]
        [DataType(DataType.EmailAddress)]
        [Required]
        [RegularExpression(@"\A(?:[a-z!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z",
        ErrorMessage = "Please enter correct email address")]
        public string Mfg_Email { get; set; }

        [Required]
        public string Gst_No { get; set; }

        [Required]
        public string Pan_No { get; set; }

        [Display(Name = "Contact Number")]
        [Required]
        public string Contact { get; set; }



    }
}