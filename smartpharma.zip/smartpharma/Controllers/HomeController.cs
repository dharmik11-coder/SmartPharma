﻿using smartpharma.Helper;
using smartpharma.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using smartpharma.Models;

namespace smartpharma.Controllers
{

    public class HomeController : Controller
    {

        public ActionResult Index()
        {

            CategoryVM obj = new CategoryVM();
            CategoryModel model = new CategoryModel();
            ItemModel model1 = new ItemModel();
            obj.CategoryList = model.GetCategoryList();
            obj.ItemList = model1.GetItemList().Take(9).ToList();
            return View(obj);
        }

        public ActionResult Products(int subcategoryid)
        {
            CategoryVM obj = new CategoryVM();
            CategoryModel model = new CategoryModel();
            ItemModel model1 = new ItemModel();
            obj.CategoryList = model.GetCategoryList();
            obj.ItemList = model1.GetItemList(subcategoryid).Take(9).ToList();
            return View(obj);

        }

        public ActionResult Product_Details(int itemid)
        {
            CategoryVM obj = new CategoryVM();
            CategoryModel model = new CategoryModel();
            ItemModel model1 = new ItemModel();
            obj.CategoryList = model.GetCategoryList();
            obj.Item = model1.GetItemDetails(itemid);
            return View(obj);

        }
    }
}