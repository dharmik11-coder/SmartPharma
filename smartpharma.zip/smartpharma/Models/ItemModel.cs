﻿using smartpharma.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace smartpharma.Models
{
    public class ItemModel
    {
        Database1Entities db = new Database1Entities();

        public List<ItemVM> GetItemList()
        {
            List<ItemVM> lstItems = new List<ItemVM>();
            lstItems = (from i in db.Items
                        select new ItemVM()
                        {
                            Item_Id = i.Item_Id,
                            Item_Name = i.Item_Name,
                            Item_Price = i.Price,
                            Image_Path = i.Item_Path,
                            Item_Description = i.Item_Desc,
                            Category_Name = i.Category.Category_Name,
                            Subcategory_Name = i.Subcategory.Subcategory_Name

                        }).ToList();
            return lstItems;

        }
        public List<ItemVM> GetItemList(int subcategoryid)
        {
            List<ItemVM> lstItems = new List<ItemVM>();
            lstItems = (from i in db.Items.Where(m=>m.Subcategory_Id==subcategoryid)
                        select new ItemVM()
                        {
                            Item_Id = i.Item_Id,
                            Item_Name = i.Item_Name,
                            Item_Price = i.Price,
                            Image_Path = i.Item_Path,
                            Item_Description = i.Item_Desc,
                            Category_Name = i.Category.Category_Name,
                            Subcategory_Name = i.Subcategory.Subcategory_Name

                        }).ToList();
            return lstItems;


        }

        public List<SubcategoryVM> GetSubCategoryList(int categoryId)
        {
            List<SubcategoryVM> lstSubcategory = new List<SubcategoryVM>();
            lstSubcategory = (from s in db.Subcategories.Where(m => m.Category_Id == categoryId)
                       select new SubcategoryVM()
                       {
                           Subcategory_Id=s.Subcategory_Id,
                           Subcategory_Name=s.Subcategory_Name
                       }).ToList();
            return lstSubcategory;
        }

        public List<SelectListItem> DDLCategory()
        {
            List<SelectListItem> lstCategory = new List<SelectListItem>();
            var data = db.Categories.ToList();
            foreach (var item in data)
            {
                lstCategory.Add(new SelectListItem()
                {
                    Text = item.Category_Name,
                    Value = item.Category_Id.ToString(),
                    Selected = item.Category_Id == 0

                });
            }
            return lstCategory;
        }



        public List<SelectListItem> DDLSubcategory()
        {
            List<SelectListItem> lstSubcategory = new List<SelectListItem>();
            var data = db.Subcategories.ToList();
            foreach (var item in data)
            {
                lstSubcategory.Add(new SelectListItem()
                {
                    Text = item.Subcategory_Name,
                    Value = item.Subcategory_Id.ToString(),
                    Selected = item.Category_Id == 0

                });
            }
            return lstSubcategory;
        }



        public ItemVM GetItemDetails(int id)
        {
            try
            {
                ItemVM iVM = new ItemVM();
                iVM = (from i in db.Items.Where(m => m.Item_Id == id)
                       select new ItemVM()
                       {
                           Item_Id = i.Item_Id,
                           Item_Name = i.Item_Name,
                           Item_Price = i.Price,
                           // Image_Path = i.Item_Path,
                           Item_Description = i.Item_Desc,
                           Category_Id = i.Category_Id,
                           Subcategory_Id = i.Subcategory_Id,
                           ItemImageList = (from im in db.ItemImages.Where(x => x.Item_Id == i.Item_Id)
                                            select new ItemImageVM()
                                            {

                                                ItemImage_Id=im.ItemImage_Id,
                                                Item_Id=im.Item_Id,
                                                Image_Path=im.Image_Path
                                            }).ToList()


                       }).FirstOrDefault();
                return iVM;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                
                throw;
            }

        }


        public bool Create(ItemVM obj)
        {
            try
            {
                Item i = new Item();
                i.Item_Name = obj.Item_Name;
                i.Item_Desc = obj.Item_Name;
                i.Price = obj.Item_Price;
               // i.Item_Path = obj.Image_Path;
                i.Category_Id = obj.Category_Id;
                i.Subcategory_Id = obj.Subcategory_Id;
                db.Items.Add(i);
                db.SaveChanges();

                foreach(var item in obj.ImagePathList)
                {
                    ItemImage objImage = new ItemImage();
                    objImage.Item_Id = i.Item_Id;
                    objImage.Image_Path = item;
                    db.ItemImages.Add(objImage);
                    db.SaveChanges();
                }
                return true;
            }
            catch (Exception)
            {
                return false;

            }

        }


        public bool UpdateItem(ItemVM obj)
        {
            try
            {
                Item i;
                i = db.Items.Where(m => m.Item_Id == obj.Item_Id).FirstOrDefault();
                if(i!=null)
                {
                    i.Item_Name = obj.Item_Name;
                    i.Price = obj.Item_Price;
                    i.Item_Path = obj.Image_Path;
                    i.Item_Desc = obj.Item_Description;
                    i.Category_Id = obj.Category_Id;
                    i.Subcategory_Id = obj.Subcategory_Id;
                    db.SaveChanges();
                    foreach (var item in obj.ImagePathList)
                    {
                        ItemImage objImage = new ItemImage();
                        objImage.Item_Id = i.Item_Id;
                        objImage.Image_Path = item;
                        db.ItemImages.Add(objImage);
                        db.SaveChanges();
                    }
                    return true;
                }
                else
                {
                    return false;
                }
              
               
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                return false;
            }

        }


        public bool Delete(int id)
        {
            try
            {
                Item i;
                i = db.Items.Where(m => m.Item_Id == id).FirstOrDefault();
                if (i != null)
                {
                    db.Items.Remove(i);
                    db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
                
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                return false;
            }
           
}
    }

}