﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace smartpharma.ViewModel
{
    public class PurchaseVM
    {

        public int Purchase_Id { get; set; }

        public List<PurchaseVM> PurchaseList { get; set; }

        [Display(Name = "Purchase Date")]
        [Required]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime Purchase_Date { get; set; }
        public decimal Tax { get; set; }

        [Display(Name = "Total Amount")]
        [Required]
        public decimal Total_amount { get; set; }

        [Display(Name = "Item Name")]

        public string Item_Name { get; set; }

        public int Item_Id { get; set; }

        [Display(Name = "Manufacturer Name")]
        public string Mfg_Name { get; set; }

        public int Mfg_Id { get; set; }

        public PurchaseTransactionVM purchaseItems { get; set; }




    }
}