﻿using smartpharma.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace smartpharma.Models
{
    public class SupplierModel
    {
       
            Database1Entities db = new Database1Entities();

            public List<SupplierVM> GetSupplierList()
            {
                List<SupplierVM> lstSuppliers = new List<SupplierVM>();
                lstSuppliers = (from s in db.Suppliers
                            select new SupplierVM()
                            {
                                Supplier_Id = s.Supplier_Id,
                                Supplier_Name = s.Supplier_Name,
                                Address = s.Address,
                                Pincode = s.Pincode,
                                Email_Id = s.Email_Id,
                                Contact_Number = s.Contact,
                    

                            }).ToList();
                return lstSuppliers;


            }

        public bool Create(SupplierVM obj)
        {
            try
            {
                Supplier s = new Supplier();
                s.Supplier_Name = obj.Supplier_Name;
                s.Address = obj.Address;
                s.Pincode = obj.Pincode;
                s.Email_Id = obj.Email_Id;
                s.Contact = obj.Contact_Number;
                db.Suppliers.Add(s);
                db.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;

            }

        }

        public bool Delete(int id)
        {
            try
            {
                Supplier s;
                s = db.Suppliers.Where(m => m.Supplier_Id == id).FirstOrDefault();
                if (s != null)
                {
                    db.Suppliers.Remove(s);
                    db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                return false;
            }

        }

        public SupplierVM GetSupplierDetails(int id)
        {
            try
            {
                SupplierVM sVM = new SupplierVM();
                sVM = (from s in db.Suppliers.Where(m => m.Supplier_Id == id)
                       select new SupplierVM()
                       {
                           Supplier_Id = s.Supplier_Id,
                           Supplier_Name = s.Supplier_Name,
                           Address = s.Address,
                           Pincode = s.Pincode,
                           Email_Id = s.Email_Id,
                           Contact_Number = s.Contact,


                       }).FirstOrDefault();
                return sVM;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);

                throw;
            }

        }

        public bool UpdateSupplier(SupplierVM obj)
        {
            try
            {
                Supplier s;
                s = db.Suppliers.Where(m => m.Supplier_Id == obj.Supplier_Id).FirstOrDefault();
                if (s != null)
                {
                    
                    s.Supplier_Name = obj.Supplier_Name;
                    s.Address = obj.Address;
                    s.Pincode = obj.Pincode;
                    s.Email_Id = obj.Email_Id;
                    s.Contact = obj.Contact_Number;
                    
                    db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }


            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                return false;
            }

        }
    }
}