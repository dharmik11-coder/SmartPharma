﻿using smartpharma.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace smartpharma.Models
{
    public class CategoryModel
    {
        Database1Entities db = new Database1Entities();

        public List<CategoryVM> GetCategoryList()
        {
            List<CategoryVM> lstCategories = new List<CategoryVM>();
            lstCategories = (from c in db.Categories
                        select new CategoryVM()
                        {
                            Category_Id = c.Category_Id,
                            Category_Name = c.Category_Name,
                            SubCategoryList=(from s in db.Subcategories.Where(m=>m.Category_Id==c.Category_Id)
                                             select new SubcategoryVM()
                                             {
                                                 Subcategory_Id=s.Subcategory_Id,
                                                 Subcategory_Name=s.Subcategory_Name
                                             }).ToList()

                        }).ToList();
            return lstCategories;


        }


        public bool Create(CategoryVM obj)
        {
            try
            {
                                
                    Category c = new Category();
                    c.Category_Name = obj.Category_Name;
                    db.Categories.Add(c);
                    db.SaveChanges();
                    return true;
                }
      
            catch (Exception)
            {

                return false;

            }

          
        }

        public CategoryVM GetCategoryDetails(int id)
        {
            try
            {
                CategoryVM cVM = new CategoryVM();
                cVM = (from i in db.Categories.Where(m => m.Category_Id == id)
                       select new CategoryVM()
                       {
                           Category_Id = i.Category_Id,
                           Category_Name = i.Category_Name

                       }).FirstOrDefault();
                return cVM;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);

                throw;
            }

        }


        public bool Delete(int id)
        {
            try
            {
                Category c;
                c = db.Categories.Where(m => m.Category_Id == id).FirstOrDefault();
                if (c != null)
                {
                    db.Categories.Remove(c);
                    db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                return false;
            }
           
        }

        public bool UpdateCategory(CategoryVM obj)
        {

            try
            {
                Category c;
                c = db.Categories.Where(m => m.Category_Id == obj.Category_Id).FirstOrDefault();
                if (c != null)
                {
                    c.Category_Name = obj.Category_Name;

                    db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                return false;
            }


        }

    }
}