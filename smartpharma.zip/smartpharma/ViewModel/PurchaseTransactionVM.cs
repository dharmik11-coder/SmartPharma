﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace smartpharma.ViewModel
{
    public class PurchaseTransactionVM
    {
        public int PurchaseTransaction_id  { get; set; }

        public int Purchase_Id { get; set; }

        public int Item_Id  { get; set; }

        public int Quantity { get; set; }

        [Display(Name = "Item Price")]        
        public decimal Item_Price  { get; set; }

        [Display(Name = "Total")]       
        public decimal Total { get; set; }
    }
}