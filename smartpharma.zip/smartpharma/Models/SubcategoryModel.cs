﻿using smartpharma;
using smartpharma.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace smartpharma.Models
{    
    public class SubcategoryModel
    {

        Database1Entities db = new Database1Entities();

        public List<SubcategoryVM> GetSubcategoryList()
        {
            List<ViewModel.SubcategoryVM> lstSubcategories = new List<SubcategoryVM>();
            lstSubcategories = (from s in db.Subcategories
                             select new SubcategoryVM()
                             {
                                 Subcategory_Id = s.Subcategory_Id,
                                 Subcategory_Name = s.Subcategory_Name,
                                 Category_Name = s.Category.Category_Name,

                             }).ToList();
            return lstSubcategories;


        }

        public bool Create(SubcategoryVM obj)
        {
            try
            {

                Subcategory s = new Subcategory();
                s.Subcategory_Name = obj.Subcategory_Name;
                s.Category_Id = obj.Category_Id;
                db.Subcategories.Add(s);
                db.SaveChanges();
                return true;
            }

            catch (Exception)
            {

                return false;

            }


        }

        public SubcategoryVM GetSubcategoryDetails(int id)
        {
            try
            {
                SubcategoryVM sVM = new SubcategoryVM();
                sVM = (from i in db.Subcategories.Where(m => m.Subcategory_Id == id)
                       select new SubcategoryVM()
                       {
                           Subcategory_Id = i.Subcategory_Id,
                           Subcategory_Name = i.Subcategory_Name,
                           Category_Name =i.Category.Category_Name

                       }).FirstOrDefault();
                return sVM;
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);

                throw;
            }

        }

        public bool Delete(int id)
        {
            try
            {
                Subcategory s;
                s = db.Subcategories.Where(m => m.Subcategory_Id == id).FirstOrDefault();
                if (s != null)
                {
                    db.Subcategories.Remove(s);
                    db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                return false;
            }

        }

        public bool UpdateSubcategory(SubcategoryVM obj)
        {

            try
            {
                Subcategory s;
                s = db.Subcategories.Where(m => m.Subcategory_Id == obj.Subcategory_Id).FirstOrDefault();
                if (s != null)
                {
                    s.Subcategory_Name = obj.Subcategory_Name;
                    s.Category_Id = obj.Category_Id;
                    db.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                ExceptionLogging.SendErrorToText(ex);
                return false;
            }


        }

         public List<SelectListItem> DDLCategory()
        {
            List<SelectListItem> lstCategory = new List<SelectListItem>();
            var data = db.Categories.ToList();
            foreach (var item in data)
            {
                lstCategory.Add(new SelectListItem()
                {
                    Text = item.Category_Name,
                    Value = item.Category_Id.ToString(),
                    Selected = item.Category_Id == 0

                });
            }
            return lstCategory;
        }

    }
}

