﻿using smartpharma.Models;
using smartpharma.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace smartpharma.Controllers
{
    public class CategoryController : Controller
    {
        // GET: Category
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CategoryList()
        {
            CategoryModel model = new CategoryModel();
            List<CategoryVM> lstCategories = new List<CategoryVM>();
            lstCategories = model.GetCategoryList();
            return View(lstCategories);
        }


        public ActionResult Create(CategoryVM obj)
        {
            bool isAdded = false;
            if (ModelState.IsValid)
            {
                CategoryModel model = new CategoryModel();
                isAdded = model.Create(obj);
                if (isAdded)
                {
                    return RedirectToAction("CategoryList");
                }
                else
                {
                    return View();
                }
            }
            else
            {
                return View();
            }

        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            bool isDeleted = false;
            CategoryModel model = new CategoryModel();
            isDeleted = model.Delete(id);
            if (isDeleted)
            {
                return RedirectToAction("CategoryList");
            }
            else
            {
                ViewBag.ItemDeleteErrorMessage = "Category can not delete";
                return RedirectToAction("CategoryList");

            }

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            CategoryVM cVM = new CategoryVM();
            CategoryModel model = new CategoryModel();
            cVM = model.GetCategoryDetails(id);
            return View(cVM);
        }


        [HttpPost]
        public ActionResult Edit(CategoryVM obj)
        {

            CategoryModel model = new CategoryModel();
            if (ModelState.IsValid)
            {
                bool isUpdated = false;
                isUpdated = model.UpdateCategory(obj);
                if (isUpdated)
                {
                    return RedirectToAction("CategoryList");
                }
                else
                {
                    return View();
                }

            }
            else
            {
                return View();
            }

        }

        }
    }