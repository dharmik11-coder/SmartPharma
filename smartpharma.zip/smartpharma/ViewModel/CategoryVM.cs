﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace smartpharma.ViewModel
{
    public class CategoryVM
    {

        public int Category_Id { get; set; }

        [Display(Name = "Category Name")]
        [Required]
        public string Category_Name { get; set; }

        public string Data_Filter { get; set; }

        public List<CategoryVM> CategoryList { get; set; }

        public List<SubcategoryVM> SubCategoryList { get; set; }

        public List<ItemVM> ItemList { get; set; }

        public ItemVM Item { get; set; }
    }
}