﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using smartpharma.Models;
using smartpharma.ViewModel;
using System.IO;
using System.Web.Script.Serialization;

namespace smartpharma.Controllers
{
    public class ItemController : Controller
    {
        // GET: Item
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ItemList()
        {
            ItemModel model = new ItemModel();
            List<ItemVM> lstItem = new List<ItemVM>();
            lstItem = model.GetItemList();
            return View(lstItem);
        }


        [HttpGet]
        public ActionResult Edit(int id)
        {
            ItemVM iVM = new ItemVM();
            ItemModel model = new ItemModel();
            iVM = model.GetItemDetails(id);
            ViewBag.DDLCategory = model.DDLCategory();
            ViewBag.DDLSubcategory = model.DDLSubcategory();
            return View(iVM);
        }
        [HttpPost]
        public ActionResult Edit(ItemVM obj)
        {
            string filExtension = "";
            ItemModel model = new ItemModel();
            if (ModelState.IsValid)
            {
                //    if (obj.Item_Image != null)
                //    {
                //        Guid fileGuid = Guid.NewGuid();
                //        filExtension = Path.GetExtension(obj.Item_Image.FileName);
                //        string path = Server.MapPath("~/Upload/" + fileGuid.ToString() + filExtension);
                //        obj.Item_Image.SaveAs(path);
                //        obj.Image_Path = "/Upload/" + fileGuid.ToString() + filExtension;// path to store file in database
                //    }
                obj.ImagePathList = new List<string>();
                foreach (HttpPostedFileBase file in obj.ImageFiles)
                {
                    //Checking file is available to save.  
                    if (file != null)
                    {
                        Guid fileGuid = Guid.NewGuid();
                        filExtension = Path.GetExtension(file.FileName);
                        string path = Server.MapPath("~/Upload/" + fileGuid.ToString() + filExtension);
                        //Save file to server folder  
                        file.SaveAs(path);
                        obj.Image_Path = "/Upload/" + fileGuid.ToString() + filExtension;
                        obj.ImagePathList.Add(obj.Image_Path);
                        //assigning file uploaded status to ViewBag for showing message to user.  
                        //  ViewBag.UploadStatus = files.Count().ToString() + " files uploaded successfully.";
                    }

                }

                bool isUpdated = false;
                isUpdated = model.UpdateItem(obj);
                if (isUpdated)
                {
                    return RedirectToAction("ItemList");
                }
                else
                {
                    ViewBag.DDLCategory = model.DDLCategory();
                    ViewBag.DDLSubcategory = model.DDLSubcategory();
                    return View();
                }

            }
            else
            {
                ViewBag.DDLCategory = model.DDLCategory();
                ViewBag.DDLSubcategory = model.DDLSubcategory();
                return View();
            }

           
           

           
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            bool isDeleted = false;
            ItemModel model = new ItemModel();
            isDeleted = model.Delete(id);
            if (isDeleted)
            {
                return RedirectToAction("ItemList");
            }
            else
            {
                ViewBag.ItemDeleteErrorMessage = "item can not delete";
                return RedirectToAction("ItemList");

            }

        }

        [HttpPost]
        public ActionResult GetSubCategoryList(int categoryId)
        {
            List<SubcategoryVM> lstSubCategory = new List<SubcategoryVM>();
            ItemModel model = new ItemModel();
            lstSubCategory = model.GetSubCategoryList(categoryId);
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            string result = javaScriptSerializer.Serialize(lstSubCategory);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult Create()
        {
            ItemModel model = new ItemModel();
            ViewBag.DDLCategory = model.DDLCategory();
            ViewBag.DDLSubcategory = model.DDLSubcategory();
            return View();
        }

      
        public ActionResult Create(ItemVM obj)
        {
            bool isAdded=false;
            string filExtension = "";
            if (ModelState.IsValid)
            {
                //Guid fileGuid = Guid.NewGuid();
                //filExtension = Path.GetExtension(obj.Item_Image.FileName);
                //string path = Server.MapPath("~/Upload/" + fileGuid.ToString() + filExtension);
                //obj.Item_Image.SaveAs(path);
                //obj.Image_Path = "/Upload/" + fileGuid.ToString() + filExtension;// path to store file in database
                obj.ImagePathList = new List<string>();
                    foreach (HttpPostedFileBase file in obj.ImageFiles)
                    {
                        //Checking file is available to save.  
                        if (file != null)
                        {
                        Guid fileGuid = Guid.NewGuid();
                        filExtension = Path.GetExtension(file.FileName);
                        string path = Server.MapPath("~/Upload/" + fileGuid.ToString() + filExtension);
                        //Save file to server folder  
                        file.SaveAs(path);
                        obj.Image_Path = "/Upload/" + fileGuid.ToString() + filExtension;
                        obj.ImagePathList.Add(obj.Image_Path);
                            //assigning file uploaded status to ViewBag for showing message to user.  
                          //  ViewBag.UploadStatus = files.Count().ToString() + " files uploaded successfully.";
                        }

                    }
                
                ItemModel model = new ItemModel();              
                isAdded=model.Create(obj);
                if(isAdded)
                {
                    return RedirectToAction("ItemList");
                }
                else
                {
                    return View();
                }
            }
            else
            {
                return View();
            }

        }

    }
}