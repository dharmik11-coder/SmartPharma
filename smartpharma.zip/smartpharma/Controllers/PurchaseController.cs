﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using smartpharma.Models;
using smartpharma.ViewModel;

namespace smartpharma.Controllers
{
    public class PurchaseController : baseuserController
    {


        public ActionResult Index()
        {
            return View();
        }

        public ActionResult PurchaseList()
        {
            PurchaseModel model = new PurchaseModel();

            return View(model.GetPurchaseList());
        }

        [HttpGet]
        public ActionResult Create()
        {
            PurchaseModel model = new PurchaseModel();

            ViewBag.DDLItem = model.DDLItem();
            ViewBag.DDLMfg = model.DDLMfg();

            return View();
        }

        [HttpPost]
        public ActionResult Create(PurchaseVM obj)
        {
            bool isAdded = false;
            PurchaseModel model = new PurchaseModel();
            if (ModelState.IsValid)
            {
                
                isAdded = model.Create(obj);
                if (isAdded)
                {
                    return RedirectToAction("PurchaseList");
                }
                else
                {
                    ViewBag.DDLItem = model.DDLItem();
                    ViewBag.DDLMfg = model.DDLMfg();
                    return View();
                }
            }
            else
            {
                ViewBag.DDLItem = model.DDLItem();
                ViewBag.DDLMfg = model.DDLMfg();
                return View();
            }
        }

             [HttpGet]
        public ActionResult Edit (int id)
        {
            PurchaseVM PVM = new PurchaseVM();
            PurchaseModel model = new PurchaseModel();
            PVM = model.GetPurchaseDetails(id);
            ViewBag.DDLItem = model.DDLItem();
            ViewBag.DDLMfg = model.DDLMfg();

            return View(PVM);
        }

        [HttpPost]
        public ActionResult Edit(PurchaseVM obj)
        {
            bool isAdded = false;
            PurchaseModel model = new PurchaseModel();
            if (ModelState.IsValid)
            {
               
                isAdded = model.UpdatePurchase(obj);
                if (isAdded)
                {
                    return RedirectToAction("PurchaseList");
                }
                else
                {
                    ViewBag.DDLItem = model.DDLItem();
                    ViewBag.DDLMfg = model.DDLMfg();
                    return View();
                }
            }
            else
            {
                ViewBag.DDLItem = model.DDLItem();
                ViewBag.DDLMfg = model.DDLMfg();
                return View();
            }

        }



    }
}