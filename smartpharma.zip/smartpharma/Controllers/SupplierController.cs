﻿using smartpharma.Models;
using smartpharma.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace smartpharma.Controllers
{
    public class SupplierController : Controller
    {
        // GET: Supplier
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Create(SupplierVM obj)
        {
            bool isAdded = false;
            if (ModelState.IsValid)
            {
                SupplierModel model = new SupplierModel();
                isAdded = model.Create(obj);
                if (isAdded)
                {
                    return RedirectToAction("SupplierList");
                }
                else
                {
                    return View();
                }
            }
            else
            {
                return View();
            }

        }

        public ActionResult SupplierList()
        {
            SupplierModel model = new SupplierModel();
            List<SupplierVM> lstSuppliers = new List<SupplierVM>();
            lstSuppliers = model.GetSupplierList();
            return View(lstSuppliers);
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            bool isDeleted = false;
            SupplierModel model = new SupplierModel();
            isDeleted = model.Delete(id);
            if (isDeleted)
            {
                return RedirectToAction("SupplierList");
            }
            else
            {
                ViewBag.ItemDeleteErrorMessage = "Supplier can not be deleted";
                return RedirectToAction("SupplierList");

            }

        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            SupplierVM sVM = new SupplierVM();
            SupplierModel model = new SupplierModel();
            sVM = model.GetSupplierDetails(id);
            return View(sVM);
        }


        [HttpPost]
        public ActionResult Edit(SupplierVM obj)
        {

            SupplierModel model = new SupplierModel();
            if (ModelState.IsValid)
            {
                bool isUpdated = false;
                isUpdated = model.UpdateSupplier(obj);
                if (isUpdated)
                {
                    return RedirectToAction("SupplierList");
                }
                else
                {
                    return View();
                }

            }
            else
            {
                return View();
            }

        }
    }
}