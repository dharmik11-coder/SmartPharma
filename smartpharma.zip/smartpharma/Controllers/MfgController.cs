﻿using System;
using smartpharma.Models;
using smartpharma.ViewModel;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace smartpharma.Controllers
{
    public class MfgController : Controller
    {
        // GET: Mfg
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Create(MfgVM obj)
        {
            bool isAdded = false;
            if (ModelState.IsValid)
            {
                MfgModel model = new MfgModel();
                isAdded = model.Create(obj);
                if (isAdded)
                {
                    return RedirectToAction("MfgList");
                }
                else
                {
                    return View();
                }
            }
            else
            {
                return View();
            }

        }

        public ActionResult MfgList()
        {
            MfgModel model = new MfgModel();
            List<MfgVM> lstMfgs = new List<MfgVM>();
            lstMfgs = model.GetMfgList();
            return View(lstMfgs);
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            bool isDeleted = false;
            MfgModel model = new MfgModel();
            isDeleted = model.Delete(id);
            if (isDeleted)
            {
                return RedirectToAction("MfgList");
            }
            else
            {
                ViewBag.ItemDeleteErrorMessage = "Manufacturer can not be deleted";
                return RedirectToAction("MfgList");

            }

        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            MfgVM mVM = new MfgVM();
            MfgModel model = new MfgModel();
            mVM = model.GetMfgDetails(id);
            return View(mVM);
        }


        [HttpPost]
        public ActionResult Edit(MfgVM obj)
        {

            MfgModel model = new MfgModel();
            if (ModelState.IsValid)
            {
                bool isUpdated = false;
                isUpdated = model.UpdateMfg(obj);
                if (isUpdated)
                {
                    return RedirectToAction("MfgList");
                }
                else
                {
                    return View();
                }

            }
            else
            {
                return View();
            }

        }
    }
}