﻿using smartpharma.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
namespace smartpharma.Models
{
    public class PurchaseModel
    {
        Database1Entities db = new Database1Entities();

        public List<PurchaseVM> GetPurchaseList()
        {
            List<PurchaseVM> lstPurchases = new List<PurchaseVM>();
            lstPurchases = (from p in db.Purchases
                            select new PurchaseVM()
                            {
                                Purchase_Id = p.Purchase_Id,
                                Mfg_Id = p.Mfg_Id,
                                Mfg_Name=p.Mfg.Mfg_Name,
                                Purchase_Date=p.Date,
                                Total_amount=p.Total_Amount
                        }).ToList();
            return lstPurchases;


        }

        public PurchaseVM GetPurchaseDetails(int id)
        {
            PurchaseVM obj = new PurchaseVM();
            obj = (from p in db.Purchases.Where(m => m.Purchase_Id == id)
                   select new PurchaseVM()
                   {
                       Purchase_Id = p.Purchase_Id,
                       Purchase_Date = p.Date,
                       Total_amount=p.Total_Amount,
                       Mfg_Id = p.Mfg_Id
                   }).FirstOrDefault();
            obj.purchaseItems = (from pt in db.PurchaseTransactions.Where(m => m.Purchase_Id == id)
                                 select new PurchaseTransactionVM()
                                 {
                                     Item_Id = pt.Item_Id,
                                     Item_Price = pt.Item_Price,
                                     Quantity = pt.Quantity,
                                     Total = pt.Total
                                 }).FirstOrDefault();
            return obj;
                }



        public List<SelectListItem> DDLMfg()
        {
            List<SelectListItem> lstMfgs = new List<SelectListItem>();
            var data = db.Mfgs.ToList();
            foreach (var Purchase in data)
            {
                lstMfgs.Add(new SelectListItem()
                {
                    Text = Purchase.Mfg_Name,
                    Value = Purchase.Mfg_Id.ToString(),
                    Selected = Purchase.Mfg_Id == 0

                });
            }
            return lstMfgs;
        }

        public List<SelectListItem> DDLItem()
        {
            List<SelectListItem> lstItems = new List<SelectListItem>();
            var data = db.Items.ToList();
            foreach (var Purchase in data)
            {
                lstItems.Add(new SelectListItem()
                {
                    Text = Purchase.Item_Name,
                    Value = Purchase.Item_Id.ToString(),
                    Selected = Purchase.Item_Id == 0

                });
            }
            return lstItems;
        }

        public bool Create(PurchaseVM obj)
        {
            try
            {
                Purchase p = new Purchase();
                p.Mfg_Id = obj.Mfg_Id;
                p.Date = obj.Purchase_Date;
                p.Total_Amount = obj.purchaseItems.Quantity * obj.purchaseItems.Item_Price;              
                db.Purchases.Add(p);
                db.SaveChanges();

                PurchaseTransaction pt = new PurchaseTransaction();
                pt.Purchase_Id = p.Purchase_Id;
                pt.Item_Id = obj.purchaseItems.Item_Id;
                pt.Quantity = obj.purchaseItems.Quantity;
                pt.Item_Price = obj.purchaseItems.Item_Price;
                pt.Total = obj.purchaseItems.Quantity * obj.purchaseItems.Item_Price;
                db.PurchaseTransactions.Add(pt);
                db.SaveChanges();

                Stock s;
                s = db.Stocks.Where(m => m.Item_Id == obj.purchaseItems.Item_Id).FirstOrDefault();
                if(s!=null)
                {
                    s.Current_Stock = s.Current_Stock + obj.purchaseItems.Quantity;
                }
                else
                {
                    s = new Stock();
                    s.Item_Id = obj.purchaseItems.Item_Id;
                    s.Current_Stock = obj.purchaseItems.Quantity;
                    db.Stocks.Add(s);                  
                }
                db.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;

            }

        }

        public bool UpdatePurchase(PurchaseVM obj)
        {
            int oldItemQuantity;
            try
            {
                Purchase p;
                p = db.Purchases.Where(m => m.Purchase_Id == obj.Purchase_Id).FirstOrDefault();
                p.Date = obj.Purchase_Date;
                p.Total_Amount = obj.purchaseItems.Quantity * obj.purchaseItems.Item_Price;
                p.Mfg_Id = obj.Mfg_Id;
                //db.Purchases.Update();
                db.SaveChanges();

                PurchaseTransaction pt;
                pt = db.PurchaseTransactions.Where(m => m.Purchase_Id == obj.Purchase_Id).FirstOrDefault();
                oldItemQuantity = pt.Quantity;
                pt.Item_Id = obj.purchaseItems.Item_Id;
                pt.Quantity = obj.purchaseItems.Quantity;
                pt.Item_Price = obj.purchaseItems.Item_Price;
                pt.Total = obj.purchaseItems.Quantity * obj.purchaseItems.Item_Price;
                db.SaveChanges();

                Stock s;
                s = db.Stocks.Where(m => m.Item_Id == pt.Item_Id).FirstOrDefault();
               // s.Item_Id = pt.Item_Id;
                if (s != null)
                {
                    if (obj.purchaseItems.Quantity > oldItemQuantity)
                    {
                        s.Current_Stock = s.Current_Stock + (obj.purchaseItems.Quantity - oldItemQuantity);

                    }
                    else
                    {

                        s.Current_Stock = s.Current_Stock - (oldItemQuantity - obj.purchaseItems.Quantity);
                    }
                }

                db.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
        }

    }
}